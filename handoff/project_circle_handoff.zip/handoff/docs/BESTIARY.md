# Bestiary (WDROŻONE 13.11 — opisy zaakceptowane)

Kod: `game/bestiary/` (data.py = wpisy i kolory miejsc, progress.py = co wie zapis, screen.py = ekran). Bossowie: cały wpis od razu po 1 wygranej (Milo i Void są tylko raz).

Zasady (ZATWIERDZONE 13.11): przycisk **Bestiary** w menu ESC na mapie; **każdy zapis ma własny** bestiariusz. Wpis odkrywa się etapami: **1 pokonany** → nazwa i obrazek, **5** → opis i statystyki (HP, obrażenia, typ, biom), **15** → dropy (niezdobyte jako „???”). Widać też liczbę pokonanych. Spotkany, ale niepokonany = ciemna sylwetka „???”.
Obrazek: na razie kształt i kolor wroga z walki; własny sprite: `assets/img/bestiary/<nazwa>.png` (gdy będzie).

## Village
- **Small Slime** — A hop, a bounce, a squish. The first thing every newcomer learns to shoot.
- **Big Slime** — Too much slime in one place. Pop it and it falls apart into smaller ones.
- **Shooter** — Keeps its distance and takes potshots. Nobody remembers where it learned to aim.

## Rainbow Fields
- **Rainbow Slime** — A slime that swallowed a rainbow. When it bursts, the colours fly out in a ring.
- **Flower Spitter** — Spits seeds that split in the air and drift after you. Likes to stay out of reach.
- **Rainbow Guard** — Stands between the fields and the road. Answers every question with a shotgun.

## Sugarwood Grove
- **Gum Goblin** — Chews, aims, spits. Whatever it hits stays stuck for a moment.
- **Candy Shroom** — Spins on the spot and sprays sweet, poisonous spores everywhere.
- **Toffee Runner** — Never runs in a straight line. Never stops running, either.
- **Sugar Caster** — Throws sugar bombs from a safe distance. Sometimes it carries something precious.
- **Shroom Guard** — The Shroom Mother's bodyguard. While one of them stands, she can't be hurt.

## Toy Factory
- **Toy Soldier** — Wound up once, marching ever since. Its key never stops turning.
- **Portable Factory** — A factory on legs. Builds more toys while it shoots at you.
- **Robo-Tesla** — Crackles with stray current. Its waves leave you weaker.
- **Robo-Bomber** — Lobs burning bombs over everything. Loves the sound of explosions.
- **Scrap Beetle** — Made from leftovers. Leaves mines wherever it crawls.
- **Line Soldier** — Fresh off the Assembly Line. Still smells of paint.
- **Line Beetle** — A half-finished beetle. It doesn't know it isn't done.
- **Belt Turret** — Rides the conveyor belt and fires down the line.
- **Bomb Crate** — Fragile. Do not shake. Goes off in a ring of bullets.

## Silverpine Tundra
- **Frost Wolf** — Hunts in the snow. No tricks, just teeth and speed.
- **Ice Shooter** — Its icy bolts slow you down. Patient, cold, always a step back.
- **Frozen Orb** — A pulsing ball of ice. Its bullets bounce off the walls.
- **Tundra Watcher** — Watches the snow for anything that moves. Answers with icicles.

## Underground Garden
- **Pixie** — Blinks from place to place and fires a stream of dizzying sparks.
- **Rainbow Pixie** — Harmless-looking until it bursts. Then there are more of them.
- **Poison Skeleton** — Bones held together by poison. Keeps its distance and keeps shooting.
- **Inferno Flower** — A flower that grew where nothing should. Its seeds burn.
- **Frost Flower** — A flower that grew where nothing should. Its seeds freeze and weaken.
- **Toxic Flower** — A flower that grew where nothing should. Its seeds poison and melt armour.
- **Firefly Queen** — Glows, then dashes. Catch her mid-dash if you're feeling lucky.

## The Core
- **Skeleton** — Walks at you. That's all it does. It's enough.
- **Mecha-Skeleton** — A skeleton someone upgraded: binding mines, burning shots, and friends.
- **Liche** — Old and patient. Everything it casts makes the world spin.
- **Guard** — Guards the Core. Very tough, very slow, very sure it's doing the right thing.
- **Fly** — Buzzes at you and bursts into poison when swatted.
- **Generator** — Keeps the Core running. Builds walls of glue to keep you out.

## The Void
- **Voidling** — A piece of the Void that learned to walk. More of them come out of it.
- **Red Crystal** — Burns everything it looks at.
- **Purple Crystal** — Turns your world upside down, then breaks into smaller pieces.
- **Blue Crystal** — Cold walls and waves that won't let you think straight.
- **Void Soldier** — A Toy Soldier the Void remembers wrong. Bigger. Angrier.
- **Void Beetle** — The Void's own Scrap Beetle. Its mines are darker.

## Bosses
- **Slime King** — The biggest slime there is. Hops at you, throws slime and calls its children.
- **Prism** — A hanging crystal that splits the light into bullets.
- **Shroom Mother** — Leaps out of sight and lands in a cloud of spores. Her guards keep her safe.
- **Frost Golem** — Raises walls of ice, cracks the ground and calls the snowstorm.
- **Assembly Line** — A factory that defends itself. Break its machines to reach its core.
- **Night Bloom** — Blooms in the dark and hides among its copies. Only the real one casts a shadow.
- **Mascot** — Sings. You dodge. Somebody is grading you.
- **Milo** — He kept everyone safe. Every beat of the heart.
- **???** (Void) — Everything the system cut away, stuck together. Its name never stays the same.
