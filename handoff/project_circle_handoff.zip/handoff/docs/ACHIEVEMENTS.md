# Achievementy (WDROŻONE 13.11)

Kod: `game/achievements/` (data.py = lista, tracker.py = kiedy, book.py = zapis globalny `game/text/achievements.json`, screen.py = ekran, popup.py = powiadomienie). Ikony: `tools/make_achievement_icons.py` → `assets/img/menu/achievements/`. Ekran (strony 5×3, strzałki / ←→ / kółko myszy): menu główne → Achievements oraz ESC na mapie → Achievements. Postęp liczników per save (`counters["ach"]`).

Zasady (ZATWIERDZONE 12.11):
- Zdobyte achievementy są **globalne** (widać je w menu niezależnie od zapisu), ale **postęp liczy się osobno na każdym zapisie** (np. 10 000 wrogów na jednym save).
- Grupa **Dziwne** jest ukryta („???”), dopóki się jej nie zdobędzie. Reszta jest widoczna z opisem.
- Powiadomienie (jak „New Sigil”) **nie w trakcie walki ani bossa**: pokazuje się po powrocie na mapę; końcowe (zakończenia, Milo, Void) dopiero w menu.
- Obrazki: `tools/make_achievement_icons.py` → `assets/img/menu/achievements/<id>.png` (odznaka w kolorze grupy + symbol; „???” dla ukrytych). Zaakceptowane 13.11.

Oznaczenia: 🟢 normalne przejście · 🟡 trochę wysiłku · 🔴 grind / no-hit / dziwne

## Fabuła 🟢
| # | Nazwa | Warunek |
|---|---|---|
| 1 | New in Town | pierwsza rozmowa z Milo |
| 2 | Royal Flush | pokonaj Slime Kinga |
| 3 | Shattered Expectations | pokonaj Prism |
| 4 | Mother Knows Less | pokonaj Shroom Mother |
| 5 | Chill Out | pokonaj Frost Golema |
| 6 | Quality Control | pokonaj Assembly Line |
| 7 | Lights Out | pokonaj Night Bloom |
| 8 | Showtime | skończ walkę z Maskotką |
| 9 | Every Beat | pokonaj Milo |
| 10 | Remembered | pokonaj Void |
| 11 | Round and Round | zakończenie Main |
| 12 | Almost the Truth | zakończenie Extra |
| 13 | A World That Lives | zakończenie Secret |

## Świat i NPC
| # | Nazwa | Warunek |
|---|---|---|
| 14 | Off the Hook 🟢 | oddaj Hook Anglerowi |
| 15 | Can You Hear Me Now? 🟢 | napraw anteny Hala |
| 16 | Things That Don't Fit 🟢 | skończ śledztwo Wren |
| 17 | Overtime 🟢 | skończ quest Foremana |
| 18 | Feeling a Bit Pale 🟢 | wejdź do Pale World |
| 19 | Peacekeeper 🟡 | znajdź Peace Gun |
| 20 | Behind the Wall 🟡 | znajdź ukrytą halę w Factory |
| 21 | Keeper of Memories 🟡 | miej naraz 3 lore itemy |
| 22 | Sticker Album 🔴 | wszystkie 13 sigili |
| 23 | Cartographer 🔴 | odkryj 100% Underground Garden (mapa M) |
| 24 | Mind the Gap 🔴 | odkryj 100% Void (mapa M) |
| 25 | Tourist 🔴 | odkryj 100% Surface |
| 26 | Been There, Done That 🔴 | odkryj 100% wszystkich miejsc (Surface, Cellar, Lunapark, Core, Void) |

## Minigry
| # | Nazwa | Warunek |
|---|---|---|
| 27 | Memory Like an Elephant 🟡 | wygraj memory u Dot z ≥16 s na zegarze |
| 28 | Number Cruncher 🟡 | wygraj trudne sudoku u Bramble |
| 29 | The Big One 🟡 | złów perłę u Olivera |
| 30 | Gamble Addict 🔴 | zakręć kołem Lucky'ego 50 razy |
| 31 | Sudoku Addict 🔴 | wygraj 15 sudoku |
| 32 | Encore! 🟡 | ocena A u Maskotki |

## Walka i grind
| # | Nazwa | Warunek |
|---|---|---|
| 33 | Untouchable 🟢 | wygraj zwykłą walkę bez trafienia |
| 34 | Close Shave 🟡 | wygraj walkę mając ≤5% HP |
| 35 | Pest Control 🟡 | pokonaj 1 000 wrogów |
| 36 | Is This Your Job Now? 🔴 | pokonaj 10 000 wrogów |
| 37 | Dragon Hoard 🔴 | miej naraz 50 000$ |
| 38 | Shopaholic 🟡 | kup 50 rzeczy w sklepie |
| 39 | Know Thy Enemy 🔴 | wypełnij cały Bestiary |
| 40 | Pacifist (Mostly) 🔴 | wygraj walkę ani razu nie strzelając |
| 41 | Old Faithful 🟡 | pokonaj Prism bronią startową (Simple Blaster albo Simple Pistol) |

## No-hit na Hard 🔴
| # | Nazwa | Warunek |
|---|---|---|
| 42 | Slippery | Slime King bez trafienia na Hard |
| 43 | Light Footed | Prism bez trafienia na Hard |
| 44 | Allergy Free | Shroom Mother bez trafienia na Hard |
| 45 | Ice Skater | Frost Golem bez trafienia na Hard |
| 46 | Zero Defects | Assembly Line bez trafienia na Hard |
| 47 | Sixth Sense | Night Bloom bez trafienia na Hard |
| 48 | Perfect Pitch | Maskotka bez trafienia na Hard |
| 49 | Heartless | Milo bez trafienia na Hard |
| 50 | Nothing Left to Lose | Void na Hard bez utraty życia |
| 51 | Untouched by the Void | Void na Hard bez trafienia |

## Tryby trudności
| # | Nazwa | Warunek |
|---|---|---|
| 52 | I Have a Life Too 🟢 | skończ grę na „I Have a Job” |
| 53 | Unemployed 🔴 | skończ grę na Hard |

## Dziwne (ukryte „???”) 🔴
| # | Nazwa | Warunek |
|---|---|---|
| 54 | Window Shopper | otwórz sklep 20 razy z rzędu bez kupowania |
| 55 | Small Talk Champion | porozmawiaj z tym samym NPC 20 razy |
| 56 | Fell for It | spadnij w otchłań w Voidzie 10 razy |
| 57 | Speedrunner | pokonaj Milo w mniej niż 1 h czasu gry |
| 58 | The House Always Wins | przegraj 10 obrotów koła z rzędu |
| 59 | Tactical Retreat | ucieknij ze 100 walk |
| 60 | Bullet Sponge | wygraj walkę, w której dostałeś 50 trafień |
| 61 | Zero Balance | wydaj pieniądze co do grosza (0$ po zakupie) |
| 62 | Just One More Reroll | zrób 5 płatnych rerolli jednego sklepu |
| 63 | Touch Grass | przejdź 20 000 kafelków po Surface |
| 64 | Small Fry | złów rybę za 1$ 10 razy |
| 65 | Déjà Vu | daj się cofnąć w czasie Milo 10 razy w jednej walce |
| 66 | Skill Issue | przegraj z tym samym bossem 10 razy |
| 67 | Fashionably Late | pokonaj Slime Kinga po 3 h czasu gry |
